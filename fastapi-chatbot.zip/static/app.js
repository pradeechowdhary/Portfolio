let sessionId = localStorage.getItem("pradeep_ai_sid") || null;

const $chat = document.getElementById("chat");
const $form = document.getElementById("form");
const $input = document.getElementById("input");

function addMessage(role, text) {
  const wrap = document.createElement("div");
  wrap.className = `msg ${role === "user" ? "user" : "bot"}`;
  const r = document.createElement("div");
  r.className = "role";
  r.textContent = role === "user" ? "You" : "Bot";
  const b = document.createElement("div");
  b.className = "bubble";
  b.textContent = text;
  wrap.appendChild(r);
  wrap.appendChild(b);
  $chat.appendChild(wrap);
  $chat.scrollTop = $chat.scrollHeight;
}

function isGreeting(t) {
  const s = t.trim().toLowerCase();
  return [
    "hi",
    "hello",
    "hey",
    "hlo",
    "hii",
    "yo",
    "good morning",
    "good afternoon",
    "good evening",
  ].includes(s);
}

async function sendMessage(message) {
  addMessage("user", message);
  if (isGreeting(message)) {
    addMessage(
      "bot",
      "Hi — I’m Pradeep’s AI assistant. Ask about his skills, projects, roles, education, ISRO work, Spring Boot, Cloud, or ML."
    );
    return;
  }
  try {
    const res = await fetch("/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, session_id: sessionId }),
    });
    if (!res.ok) {
      const txt = await res.text();
      throw new Error(`HTTP ${res.status} ${txt.slice(0, 160)}`);
    }
    const json = await res.json();
    sessionId = json.session_id;
    localStorage.setItem("pradeep_ai_sid", sessionId);
    addMessage("bot", json.reply);
  } catch (e) {
    addMessage("bot", `Request failed: ${e.message}`);
  }
}

$form.addEventListener("submit", (e) => {
  e.preventDefault();
  const text = $input.value.trim();
  if (!text) return;
  $input.value = "";
  sendMessage(text);
});

$input.addEventListener("input", () => {
  $input.style.height = "auto";
  $input.style.height = Math.min($input.scrollHeight, 160) + "px";
});

$input.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    $form.dispatchEvent(new Event("submit"));
  }
});

// initial greeting
addMessage(
  "bot",
  "Hi there! I’m Pradeep’s AI assistant. Ask about skills, ISRO work, Spring Boot, cloud, or projects."
);

// ---------------------------------------------------------------
// Dynamic hero role cycling
// After the DOM is ready, cycle through a list of roles under the hero
// heading. This mirrors the word cycle animation on Shan Irshad's site.
document.addEventListener("DOMContentLoaded", () => {
  const wordEl = document.getElementById("changing-word");
  if (!wordEl) return;
  const roles = [
    "AI Engineer",
    "Cloud Architect",
    "Software Developer",
    "Researcher",
    "Technical Product Manager",
  ];
  let index = 0;
  // Ensure the element is visible for the first word
  wordEl.textContent = roles[index];
  wordEl.style.opacity = "1";
  wordEl.style.transition = "opacity 0.6s ease-in-out";
  setInterval(() => {
    // fade out current word
    wordEl.style.opacity = "0";
    setTimeout(() => {
      index = (index + 1) % roles.length;
      wordEl.textContent = roles[index];
      wordEl.style.opacity = "1";
    }, 400);
  }, 4000);
});